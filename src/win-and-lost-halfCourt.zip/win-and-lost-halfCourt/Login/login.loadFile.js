window.fileList = {
  fileList_commonJS: [ // common js
    '../Js/utils.js',
    '../Config/config.js',
  ],
  fileList_data :[ // data
    
  ],
  fileList_ownJS :[ // own js
    './login.js'
  ]
};