window.fileList = {
  fileList_commonJS: [ // common js
    './Js/utils.js',
    './Config/config.js',
  ],
  fileList_data :[ // data
    "./Lib/data/FootballData.js",
    "./Lib/data/CalculatorData.js",
    "./Lib/data/StatusData.js"
  ],
  fileList_ownJS :[ // own js
    // './User/userInfo.js',
    './Football/football.js'
  ]
};