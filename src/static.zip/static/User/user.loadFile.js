window.fileList = {
  fileList_commonJS: [ // common js
    '../Js/utils.js',
    '../Config/config.js',
  ],
  fileList_data :[ // data
    '../Lib/data/UserList.js'
  ],
  fileList_ownJS :[ // own js
    './userInfo.js',
    './user.js'
  ]
};